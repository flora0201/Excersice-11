package com.example.Springfirstproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Demo {
    @Autowired
    Services name;
    @RequestMapping(value = "/java")
    public String display(){
        return "Hello World";
    }
    @RequestMapping
            (value = "/get parameters",method = RequestMethod.GET)
    public String Get(){
        return "Spring details";
    }
    @RequestMapping
            (value = "/sum",method = RequestMethod.GET)
    public int sum(){
        AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
        Services ms=context.getBean(Services.class);
        int sum=ms.add(1,2);
        return(sum);

    }
}
