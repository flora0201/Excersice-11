package com.example.Springfirstproject;

import org.springframework.stereotype.Service;

@Service
public class Services{
    public int add(int a,int b){
        return a+b;
    }
}
